from django.contrib import admin
from .models import info, regi

class infu(admin.ModelAdmin):
    list_display=['eid','title','price','image','desc','loc', 'hosting', 'datt','cont']

admin.site.register(info, infu)

class regis(admin.ModelAdmin):
    list_display=['fname','lname','paym','age','email','datte','pay','titli','cont','doe']

admin.site.register(regi, regis)
