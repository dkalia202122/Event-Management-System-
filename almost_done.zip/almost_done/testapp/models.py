from django.db import models

class info(models.Model):
    eid=models.IntegerField(default=1, primary_key=True)
    title=models.CharField(max_length=100)
    desc=models.TextField(max_length=1000)
    image=models.ImageField(upload_to='event/')
    price=models.CharField(max_length=100)
    loc=models.CharField(max_length=100, null=True)
    hosting=models.CharField(max_length=100, null=True)
    cont=models.TextField(max_length=150, null=True)
    datt=models.DateTimeField(auto_now_add=False)
    def get_absolute_url(self):
        return f'/image/{self.eid}/'

class regi(models.Model):
    titli=models.CharField(max_length=100, null=True)
    stat=(
        ('Cash', 'Cash'),
        ('UPI', 'UPI'),
        ('Debit Card', 'Debit Card'),
        ('Credit Card', 'Credit Card'),
    )
    pay= models.CharField(max_length=50, choices=stat)
    fname=models.CharField(max_length=15)
    lname=models.CharField(max_length=15)
    datte=models.DateTimeField(auto_now_add=True)
    doe=models.DateTimeField(auto_now_add=True, null=True)
    cont=models.TextField(max_length=150, null=True)
    paym=models.IntegerField()
    age=models.IntegerField()
    email=models.EmailField()
    def __str__(self):
        return self.fname
    def get_absolute_url(self):
        return f'/fname/{self.fname}/'
