from django.shortcuts import render, get_object_or_404
from .models import regi, info
from django.core.mail import send_mail
from django.conf import settings
from django.core.mail import send_mail
from django.http import HttpResponse
import random
import os
from django.db.models import Sum
  
value_to_pass = None

def admin(request):
    return render(request, 'admin.html')

def verify(request): #admin button pe click krke id aur password mangega
    users = {
    'shalini@bciit.ac.in': '9999418591',
    'mavats': '9650320399',
    'alok@bciit.ac.in': '9990584411',
    'sonia807batra@gmail.com': '7838484806',
    'sb.bciit@gmail.com': '9811345938',
    'kgomathy': '7299631120',
    'smharma': '9910136173',
    'antaneja': '981033527',
    'dkalia202122@hotmail.com': '9870307963',
    }
    if request.method == 'POST':
        username = request.POST.get('uname')
        password = request.POST.get('passw')
        print(username, password)
        if username in users and users[username] == password:
            otp = str(random.randint(100000, 999999))
            request.session['otp'] = otp
            message = f'Your OTP is: {otp}. Use this OTP to verify your registration.'
            send_mail(#ye wali email chlegi admin ki registration ke lye
                'Enter this otp to login',
                message,
                settings.EMAIL_HOST_USER,
                [username],
                fail_silently=False,
                )
        else:
            return HttpResponse('Invalid username or password', status=400)
    return render(request, 'otp.html')

def verify_otp(request): ##otp verify hone ke baad admin ho yha laega
    if request.method == 'POST':
        user_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')
        if user_otp != stored_otp:
            return HttpResponse("Invalid OTP. Please try again.")
    return render(request, 'verify.html')  # Method Not Allowed


def one(request):
    return render(request, 'd.html')

def done(request):
    return render(request, 'd1.html')

def than(request):
    return render(request, 'than.html')

def event(request):
    all_rows = info.objects.all()
    even_rows = [row for row in all_rows if row.eid % 2 == 0]
    odd_rows = [row for row in all_rows if row.eid % 2 != 0]
    dict={'shoo':even_rows, 'shou':odd_rows}
    return render(request, 'event.html', dict)


def regis(request, image_eid):
     if info:
          image=get_object_or_404(info, eid=image_eid)
     return render(request, 'regis.html', {'image': image})

def paym(request, image_eid): #candidate registration
     #this will run after regis
     if request.method == "POST":
        titli = request.POST.get('titli')
        pay = request.POST['pay']
        fname = request.POST['fname']
        lname = request.POST['lname']
        datte = request.POST['datte']
        doe=request.POST['datt']
        paym = request.POST['eid']
        age = request.POST['age']
        cont=request.POST['cont']
        email = request.POST.get('email')
        print(fname,lname,paym,age,titli,email)
        nw=regi(titli=titli,pay=pay,fname=fname,lname=lname,datte=datte,
                paym=paym,age=age,email=email,cont=cont,doe=doe)
        nw.save()
        if info:
          image=get_object_or_404(info, eid=image_eid)
     return render(request, 'pay.html', {'image': image})

def thankyou(request, image_eid): #candidate will receive information about completion of registration
    #and about event title, useful contacts for that event and date of event
    global value_to_con
    if request.method == "POST":
        latest_record = regi.objects.latest('datte')
        latest_titli = latest_record.titli
        latest_cont = latest_record.cont
        email = request.POST.get('email')#ye wali email chlegi after registration of event
        message = f'You have successfully registered for {latest_titli}.\n'
        msg = f'You can contact {latest_cont} for further assistance. \n'       
        full_message = message + msg
        send_mail(
            'Event Registration Completed',
            full_message,
            settings.EMAIL_HOST_USER,  # This should be the from_email
            [email],
            fail_silently=False,
            )
        if info:
          image=get_object_or_404(info, eid=image_eid)
    return render(request, 'thankyou.html', {'image': image})

def noevent(request): #send otp to authenticate admin
    return render(request, 'nevent.html')

def rdetail(request): #registration detail show to admin
    all=regi.objects.all()
    cashp = regi.objects.filter(pay='Cash')
    nonp = regi.objects.exclude(pay='Cash')
    cash = regi.objects.filter(pay='Cash').aggregate(
        total_payment=Sum('paym')
        )['total_payment']
    onl = regi.objects.exclude(pay='Cash').aggregate(
        total_payment=Sum('paym')
        )['total_payment']
    totil=onl+cash
    print(f"Total payment for cash payments: {cash}")
    print(f"Total payment for non-cash payments: {onl}")
    context = {
        'cashp': cashp,
        'nonp': nonp,
        'abbe':all,
        'cash':cash,
        'onl':onl,
        'totil':totil
    }
    return render(request, 'rdetail.html', context)

def suc(request): #add new event by admin
    if request.method == "POST":
        title = request.POST['title']
        price = request.POST['price']
        desc = request.POST['desc']
        loc = request.POST['loc']
        image = request.FILES.get('image')
        eid = request.POST['eid']
        hosting = request.POST['hosting']
        datt = request.POST['datt']
        cont=request.POST['cont']
        image_path = os.path.join('M:\\6th sem\\almost_done\\event', image.name)
        with open(image_path, 'wb') as f:
            for chunk in image.chunks():
                f.write(chunk)
        print(title,eid,loc,datt)
        nw=info(title=title,price=price,desc=desc,loc=loc,image=image,eid=eid,
                hosting=hosting,datt=datt,cont=cont)
        nw.save()
    return render(request, 'suc.html')

# def payment_filter_view(request):
#     cash_payments = regi.objects.filter(pay='Cash')
#     other_payments = regi.objects.exclude(pay='Cash')
    
#     context = {
#         'cash_payments': cash_payments,
#         'other_payments': other_payments,
#     }
#     return render(request, 'your_template.html', context)