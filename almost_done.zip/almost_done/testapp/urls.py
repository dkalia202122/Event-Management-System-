from django.urls import path
from . import views

urlpatterns=[
    path('d', views.one),
    path('d1', views.done),
    path('event', views.event, name='event'),
    path('image/<int:image_eid>/', views.regis, name='prod'),
    path('than', views.than),
    path('admin', views.admin),
    path('ver', views.verify),
    path('veri', views.verify_otp),
    path('image/<int:image_eid>/pay', views.paym),
    path('image/<int:image_eid>/thankyou.html',views.thankyou, name='thankyou'),
    path('new_event', views.noevent),
    path('reg_detail', views.rdetail),
    path('suc', views.suc),    
]
